
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'estagiario',
  applicationName: 'serverless-estagiario',
  appUid: 'GGFl2VKqNhq1mmB3lK',
  orgUid: '388e10d8-ee1a-47ed-8f4d-f589cd4741e5',
  deploymentUid: 'ee2af80b-f77b-4bdb-a8aa-3b6696f5e0f0',
  serviceName: 'serverless-estagiario',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-estagiario-dev-main', timeout: 6 };

try {
  const userHandler = require('./dist/main.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}