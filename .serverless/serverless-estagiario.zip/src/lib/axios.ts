import * as axios from 'axios';

export const wppApi = axios.default.create({
  baseURL: 'https://graph.facebook.com/v20.0/374765715711006',
  headers: {
    Authorization:
      'Bearer EAARMCGe1MUcBOw1h2brAYouZCUvEDiJ3ZB7JedFoOxcb62NrGPrdiXzyUMmGUllFbUvjbl5CXJvW6BdZCD2fK8NXZCj5xohSz3ZCX7WZAx8UuZCx72QaZCMAesIzPMoLR3YVj4L0oGJKlPy5FZBVq9OWxKTJwG5LaKuyGJaLh9bZAtrTLRbKDFikLbN0zGMRiUkPCh',
    'Content-Type': 'application/json',
  },
});
